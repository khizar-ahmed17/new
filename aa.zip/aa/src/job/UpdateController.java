package job;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
@RequestMapping("update")
public class UpdateController {

	HiberOperations db=new HiberOperations();
	
	@RequestMapping(method=RequestMethod.GET)
	public ModelAndView updatepasswordpage(UserBean ubean)
	{
		
		ModelAndView mdl=new ModelAndView();
		mdl.addObject("userbean",ubean);
		mdl.setViewName("UpdatePassword");
		return mdl;
	}
	
	
	@RequestMapping(method=RequestMethod.POST)
	public ModelAndView updatepassword(UserBean ubean)
	{
		
		ModelAndView mdl=new ModelAndView();
		db.changepassword(ubean.getUsername(),ubean.getPassword());
		mdl.addObject("userbean",ubean);
		mdl.setViewName("welcome");
		return mdl;
	}
}
