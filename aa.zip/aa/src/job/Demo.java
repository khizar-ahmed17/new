package job;

import java.util.HashSet;
import java.util.Set;

import org.hibernate.classic.Session;

public class Demo 
{
public static void main(String[] args) 
{
	ServiceProvider service=new ServiceProvider();
	service.setSp_username("company");
	service.setSp_password("root");
	service.setSp_email("company@gamil.com");
	service.setSp_website("company.com");
	service.setSp_status(0);
	service.setSp_address("1st Street");
	
	ServiceRequester service1=new ServiceRequester();
	service1.setRq_id(1);
	service1.setRq_username("job");
	service1.setRq_password("job");
	service1.setRq_email("job@gmail.com");
	service1.setRq_address("new street");
	service1.setRq_contact(2);
	service1.setRq_status(0);
	
	RequestJobs jb=new RequestJobs();
	jb.setJob_id(1);
	jb.setJob_experience("1 Year");
	jb.setJob_name("Software Developer");
	jb.setJob_specialization("Java");
	jb.setJob_amount(20000);
	jb.setRqobj(service1);
	
	
	Jobs j=new Jobs();
	j.setJob_id(1);
	j.setJob_name("java developer");
	j.setJob_amount(5000);
	j.setJob_experience("2 Years");
	j.setSpobj(service);
	
	
	
	Jobs j1=new Jobs();
	j1.setJob_id(2);
	j1.setJob_name("dot net developer");
	j1.setJob_amount(1000);
	j1.setJob_experience("1 Years");
	j1.setSpobj(service);
	
	
	Set<Jobs> set=new HashSet<Jobs>();
	set.add(j);
	set.add(j1);
	service.setJobs(set);
	
	Set<RequestJobs> set1=new HashSet<RequestJobs>();
	set1.add(jb);
	service1.setJobs(set1);
	
	
	Session session=(Session) SessionUtility.GetSessionConnection();
	session.save(service);
	session.save(j);
	session.save(j1);
	
	session.save(service1);
	session.save(jb);
	
	
	
	SessionUtility.closeSession(null);
}
}
