package job;

public class Address {

	private int aid;
	private String street;
	private String City;
	private Employee empobj;
	
	public int getaid() {
		return aid;
	}
	public void setaid(int aid) {
		this.aid = aid;
	}
	public String getStreet() {
		return street;
	}
	public void setStreet(String street) {
		this.street = street;
	}
	public String getCity() {
		return City;
	}
	public void setCity(String city) {
		City = city;
	}
	public Employee getEmpobj() {
		return empobj;
	}
	public void setEmpobj(Employee empobj) {
		this.empobj = empobj;
	}

	
	
	
}
