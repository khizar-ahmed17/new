package job;

import java.util.Iterator;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.classic.Session;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
@RequestMapping("requestapply")
public class ApplyController
{
	@Autowired
	ServiceProvider providerbean;
	
	public ServiceProvider getProviderbean() {
		return providerbean;
	}

	public void setProviderbean(ServiceProvider providerbean) {
		this.providerbean = providerbean;
	}

	@Autowired
	Jobs jobbean;
	
	public Jobs getJobbean() {
		return jobbean;
	}

	public void setJobbean(Jobs jobbean) {
		this.jobbean = jobbean;
	}

	@RequestMapping(method=RequestMethod.GET)
	public ModelAndView movetoposition(Jobs jobbean,ServiceRequester requestbean)
	{
			System.out.println("In Get method of ApplyControl");
			ModelAndView mdlv=new ModelAndView();
			System.out.println(requestbean.getRq_id());
			System.out.println("Job name:"+jobbean.getCheckjobs());
			System.out.println(jobbean.getProduct());
			for (String s  : jobbean.getProduct()) {
				//session.setAttribute(s.toString().trim(),s.toString().trim());
				System.out.println("value:"+s);
				}
			
			
			ServiceProvider providerbean=new ServiceProvider();
			Session session=(Session)SessionUtility.GetSessionConnection();
			String hql = "FROM job.ServiceProvider";
			Query query = session.createQuery(hql);
			List<ServiceProvider> results = query.list();
			Iterator<ServiceProvider> it=results.iterator();
			it.next().setApply_request(1);
			mdlv.setViewName("userwelcome");
			mdlv.addObject("jobbean",jobbean);
			mdlv.addObject("providerbean",providerbean);
			
			SessionUtility.closeSession(null);
			return mdlv;
		
		}
	
	@RequestMapping(method=RequestMethod.POST)
	public ModelAndView nextposition(Jobs jobbean)
	{
		System.out.println("In post method of Appply control");
		System.out.println("Am here");
		ModelAndView md=new ModelAndView();
		
		
	//	md.addObject("positions",results);
		md.addObject("jobbean",jobbean);
		md.setViewName("userwelcome");
		return md;
		
	}
	
	
}
