package job;

public class Jobs 
{
	private int job_id;
	private String job_name;
	private String job_experience;
	private int job_amount;
	private String job_specialization;
	private ServiceProvider spobj;
	
	
	
	
	public int getJob_id() {
		return job_id;
	}
	public void setJob_id(int job_id) {
		this.job_id = job_id;
	}
	public String getJob_name() {
		return job_name;
	}
	public void setJob_name(String job_name) {
		this.job_name = job_name;
	}
	
	public int getJob_amount() {
		return job_amount;
	}
	public void setJob_amount(int job_amount) {
		this.job_amount = job_amount;
	}
	public String getJob_specialization() {
		return job_specialization;
	}
	public void setJob_specialization(String job_specialization) {
		this.job_specialization = job_specialization;
	}
	public ServiceProvider getSpobj() {
		return spobj;
	}
	public void setSpobj(ServiceProvider spobj) {
		this.spobj = spobj;
	}
	/**
	 * @return the job_experience
	 */
	public String getJob_experience() {
		return job_experience;
	}
	/**
	 * @param job_experience the job_experience to set
	 */
	public void setJob_experience(String job_experience) {
		this.job_experience = job_experience;
	}
	
	
}