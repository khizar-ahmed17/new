package job;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
@RequestMapping("register")
public class RegisterController {

	HiberOperations db=new HiberOperations();
	
	@Autowired
	ServiceProvider userbean;
	

	public ServiceProvider getUserbean() {
		return userbean;
	}


	public void setUserbean(ServiceProvider userbean) {
		this.userbean = userbean;
	}


	@RequestMapping(method=RequestMethod.POST)
	public ModelAndView RegisterAction(ServiceProvider userbean)
	{
		ModelAndView mdl=new ModelAndView();
		
		if(db.checkuser(userbean.getSp_username().toString().trim()))
		{
			mdl.setViewName("login");
		}
		else
		{
			db.InsertDatabase(userbean.getSp_username()
					,userbean.getSp_password(),userbean.getSp_email(),
					userbean.getSp_website(),userbean.getSp_address());
			mdl.setViewName("login");
		}
		
		mdl.addObject("userbean",userbean);
		
		return mdl;
		
	}
	
	
	
	
	
}
