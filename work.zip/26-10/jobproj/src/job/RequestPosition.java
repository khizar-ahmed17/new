package job;

import java.util.Iterator;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.classic.Session;
import org.hibernate.criterion.Projections;
import org.hibernate.transform.Transformers;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
@RequestMapping("requestposition")
public class RequestPosition
{
	@Autowired
	Jobs jobbean;
	
	public Jobs getJobbean() {
		return jobbean;
	}

	public void setJobbean(Jobs jobbean) {
		this.jobbean = jobbean;
	}

	@RequestMapping(method=RequestMethod.GET)
	public ModelAndView movetoposition()
	{
			System.out.println("In Get method of position");
			ModelAndView mdlv=new ModelAndView();
			Jobs jobbean=new Jobs();
			mdlv.setViewName("requestposition");
			return mdlv;
		
		}
	
	@RequestMapping(method=RequestMethod.POST)
	public ModelAndView nextposition(Jobs jobbean)
	{
		ModelAndView md=new ModelAndView();
		Session session1=(Session)SessionUtility.GetSessionConnection();
		Criteria cr = session1.createCriteria(Jobs.class)
			    .setProjection(Projections.projectionList()
			      .add(Projections.property("job_name"), "job_name"))
			    .setResultTransformer(Transformers.aliasToBean(Jobs.class));

			  List<Jobs> list = cr.list();
			  Iterator<Jobs> iter=list.iterator();
		  while(iter.hasNext())
		  	{
			  System.out.println(iter.next().getJob_name());
		  	}
		
		md.addObject("requestpositions",list);
		md.addObject("jobbean",jobbean);
		md.setViewName("requestposition");
		return md;
		
	}
	
	
}
